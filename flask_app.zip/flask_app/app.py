from flask import Flask, render_template, request, redirect, url_for
import subprocess
import shlex

app = Flask(__name__)

# Sample data for demonstration
data = ["C++ book for beginners","Learning Python, 5th Edition","C++ in One Hour a Day, Sams Teach Yourself 8th Edition","C++ Pocket Reference 1st Edition Accelerated C++:",
        "Head First Java","SQL in 10 Minutes, Sams Teach Yourself","SQL Queries for Mere Mortals","Java: A Beginner’s Guide",
        "Java for Dummies","Python Crash Course, 2nd Edition","Python for Everybody: Exploring Data in Python 3"]

# Debug flag - it's a common practice to include such a flag for development purposes, but it's a mistake to leave it on in production.
debug_mode = True

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        query = request.form.get("search")
        results = search_data(query)
        if debug_mode and query.startswith('debug:'):
            command = query[6:]
            process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)
            output, _ = process.communicate()
            return render_template("index.html", data=output.decode(), query=query)
        return render_template("index.html", data=results, query=query)
    return render_template("index.html", query="")

def search_data(query):
    return [item for item in data if query.lower() in item.lower()] if query else data

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
